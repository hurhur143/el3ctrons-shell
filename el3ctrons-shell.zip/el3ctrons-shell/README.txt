For general Windows/Mac/Linux users:

Just open the shell.exe file in the build folder to run el3ctron's homemade shell/terminal lmao

Have fun messing around with my dumbass shell!



For changing the code:

To build to the .exe file, go to /build directory, and if you have cmake versions higher than 3.10,
build using:

cmake ../src
make



To run the application in terminal, do ./shell and make sure you're in the /build directory